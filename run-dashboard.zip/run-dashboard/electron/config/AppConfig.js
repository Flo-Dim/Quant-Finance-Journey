const path = require('path');
const { app } = require('electron');

class AppConfig {
  constructor() {
    this.baseDir = this._resolveBaseDir();
    this.dataDir = path.join(this.baseDir, 'data');
    this.runIndiceFileName = 'RUN_INDICE.xlsx';
    this.actionsEmailFileName = 'TABLEAU_DE_BORD_ACTIONS.eml';
  }

  // Déduit le dossier de base automatiquement :
  // - en .exe portable : dossier où se trouve réellement le .exe sur le réseau
  // - en dev : racine du projet
  _resolveBaseDir() {
    if (process.env.PORTABLE_EXECUTABLE_DIR) {
      return process.env.PORTABLE_EXECUTABLE_DIR;
    }
    if (app.isPackaged) {
      return path.dirname(process.execPath);
    }
    return path.join(__dirname, '..', '..');
  }

  get runIndicePath() {
    return path.join(this.dataDir, this.runIndiceFileName);
  }

  get actionsEmailPath() {
    return path.join(this.dataDir, this.actionsEmailFileName);
  }
}

module.exports = new AppConfig();
