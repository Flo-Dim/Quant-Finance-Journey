const fs = require('fs');

class PagerLocatorService {
  constructor(config) {
    this.config = config;
  }

  findPagerFor(sjName) {
    if (!sjName) return null;

    const code = this._extractCode(sjName);
    if (!code) return null;

    let files;
    try {
      files = fs.readdirSync(this.config.dataDir);
    } catch (err) {
      console.error('Impossible de lire le dossier des pagers:', err.message);
      return null;
    }

    const match = files.find(
      (f) => f.toLowerCase().endsWith('.pdf') && f.toUpperCase().includes(code.toUpperCase())
    );

    return match || null;
  }

  // "MXTPIC50 (MS)" -> "MXTPIC50"
  _extractCode(sjName) {
    return String(sjName).split(/[\s(\n]/)[0].trim();
  }
}

module.exports = PagerLocatorService;
