const XLSX = require('xlsx');
const Indice = require('../models/Indice');
const SheetData = require('../models/SheetData');

class ExcelIndiceService {
  constructor(config) {
    this.config = config;
  }

  loadAllSheets() {
    const workbook = XLSX.readFile(this.config.runIndicePath, { cellDates: true });
    const sheets = [];

    for (const sheetName of workbook.SheetNames) {
      const sheetData = this._parseSheet(workbook, sheetName);
      if (sheetData && sheetData.indices.length > 0) {
        sheets.push(sheetData);
      }
    }
    return sheets;
  }

  _parseSheet(workbook, sheetName) {
    const ws = workbook.Sheets[sheetName];
    const rows = XLSX.utils.sheet_to_json(ws, { header: 1, raw: false, defval: null });

    const headerRowIndex = rows.findIndex(
      (row) => row && row[0] === 'No' && row[1] === 'SJ'
    );
    if (headerRowIndex === -1) return null;

    const title = this._findTitle(rows, headerRowIndex, sheetName);
    const indices = this._extractIndices(rows, headerRowIndex);

    return new SheetData(sheetName, title, indices);
  }

  _findTitle(rows, headerRowIndex, fallback) {
    for (let i = headerRowIndex - 1; i >= 0; i--) {
      const cell = rows[i] && rows[i][0];
      if (cell && typeof cell === 'string' && cell.trim().length > 0) {
        return cell.replace(/:\s*$/, '').trim();
      }
    }
    return fallback;
  }

  _extractIndices(rows, headerRowIndex) {
    const indices = [];
    for (let i = headerRowIndex + 1; i < rows.length; i++) {
      const row = rows[i];
      if (!row || row[0] === null || row[0] === undefined) continue;
      if (row[0] === 'DISCLAIMER') break;
      if (isNaN(Number(row[0]))) continue;

      indices.push(
        new Indice({
          no: Number(row[0]),
          sj: row[1],
          spot: row[2],
          strike: row[3],
          cp: row[4],
          rappel: row[5],
          airbag: row[6],
          capital: row[7],
          cadre: row[8],
          description: row[9],
          date: row[10],
        })
      );
    }
    return indices;
  }
}

module.exports = ExcelIndiceService;
