class DataStore {
  constructor(excelService, emailService, pagerService) {
    this.excelService = excelService;
    this.emailService = emailService;
    this.pagerService = pagerService;
    this.sheets = [];
    this.actions = [];
    this.lastRefresh = null;
  }

  async refresh() {
    this.sheets = this.excelService.loadAllSheets();

    for (const sheet of this.sheets) {
      for (const indice of sheet.indices) {
        const pagerFile = this.pagerService.findPagerFor(indice.sj);
        indice.attachPager(pagerFile);
      }
    }

    try {
      this.actions = await this.emailService.loadActions();
    } catch (err) {
      console.error('Erreur chargement actions:', err.message);
      this.actions = [];
    }

    this.lastRefresh = new Date();
    return this.getSnapshot();
  }

  getSnapshot() {
    return { sheets: this.sheets, actions: this.actions, lastRefresh: this.lastRefresh };
  }
}

module.exports = DataStore;
