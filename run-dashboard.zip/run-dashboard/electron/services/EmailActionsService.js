const fs = require('fs');
const { simpleParser } = require('mailparser');
const ActionRow = require('../models/ActionRow');

const FIELDS_PER_ROW = 16;

class EmailActionsService {
  constructor(config) {
    this.config = config;
  }

  async loadActions() {
    const raw = fs.readFileSync(this.config.actionsEmailPath);
    const parsed = await simpleParser(raw);
    const text = parsed.text || '';
    return this._parseTable(text);
  }

  _parseTable(text) {
    const blocks = text
      .split(/\n{2,}/)
      .map((b) => b.trim())
      .filter((b) => b.length > 0);

    const startIdx = blocks.findIndex((b) => b === 'Max Hist');
    if (startIdx === -1) return [];

    const dataBlocks = blocks.slice(startIdx + 1);
    const rows = [];

    for (let i = 0; i + FIELDS_PER_ROW <= dataBlocks.length; i += FIELDS_PER_ROW) {
      const c = dataBlocks.slice(i, i + FIELDS_PER_ROW);
      rows.push(
        new ActionRow({
          secteur: c[0],
          name: c[1],
          autocall5Y: c[2],
          reco: c[3],
          potentiel: c[4],
          perf1Y: c[5],
          peAction: c[6],
          peSecteur: c[7],
          pbAction: c[8],
          pbSecteur: c[9],
          baisseMax: c[10],
          hausseMax: c[11],
          objectifCours: c[12],
          dernierCours: c[13],
          minHist: c[14],
          maxHist: c[15],
        })
      );
    }
    return rows;
  }
}

module.exports = EmailActionsService;
