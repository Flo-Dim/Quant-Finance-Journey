class SheetData {
  constructor(sheetName, title, indices) {
    this.sheetName = sheetName;
    this.title = title;
    this.indices = indices;
  }
}

module.exports = SheetData;
