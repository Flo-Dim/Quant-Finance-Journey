class Indice {
  constructor({ no, sj, spot, strike, cp, rappel, airbag, capital, cadre, description, date }) {
    this.no = no;
    this.sj = sj;
    this.spot = spot;
    this.strike = strike;
    this.cp = cp;
    this.rappelAnticipeAutomat = rappel;
    this.airbag = airbag;
    this.capital = capital;
    this.cadreUfCgp = cadre;
    this.description = description;
    this.date = date;

    // Rempli plus tard par le PagerLocatorService
    this.pagerFileName = null;
    this.pagerAvailable = false;
  }

  attachPager(fileName) {
    this.pagerFileName = fileName;
    this.pagerAvailable = !!fileName;
  }
}

module.exports = Indice;
