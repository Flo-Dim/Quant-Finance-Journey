class ActionRow {
  constructor({
    secteur, name, autocall5Y, reco, potentiel, perf1Y,
    peAction, peSecteur, pbAction, pbSecteur,
    baisseMax, hausseMax, objectifCours, dernierCours, minHist, maxHist
  }) {
    this.secteur = secteur;
    this.name = name;
    this.autocall5Y = autocall5Y;
    this.reco = reco;
    this.potentiel = potentiel;
    this.perf1Y = perf1Y;
    this.peAction = peAction;
    this.peSecteur = peSecteur;
    this.pbAction = pbAction;
    this.pbSecteur = pbSecteur;
    this.baisseMax = baisseMax;
    this.hausseMax = hausseMax;
    this.objectifCours = objectifCours;
    this.dernierCours = dernierCours;
    this.minHist = minHist;
    this.maxHist = maxHist;
  }
}

module.exports = ActionRow;
