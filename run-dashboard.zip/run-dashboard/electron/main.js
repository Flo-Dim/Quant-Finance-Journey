const { app, BrowserWindow, ipcMain, shell } = require('electron');
const path = require('path');

const config = require('./config/AppConfig');
const ExcelIndiceService = require('./services/ExcelIndiceService');
const EmailActionsService = require('./services/EmailActionsService');
const PagerLocatorService = require('./services/PagerLocatorService');
const DataStore = require('./services/DataStore');

let mainWindow;
let dataStore;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1300,
    height: 850,
    title: 'ODDO BHF — Tableau de Bord',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  if (app.isPackaged) {
    mainWindow.loadFile(path.join(__dirname, '..', 'renderer', 'dist', 'index.html'));
  } else {
    mainWindow.loadURL('http://localhost:5173');
  }
}

function registerIpcHandlers() {
  ipcMain.handle('get-snapshot', () => dataStore.getSnapshot());

  ipcMain.handle('refresh', async () => dataStore.refresh());

  ipcMain.handle('open-pager', async (event, fileName) => {
    if (!fileName) return { success: false, error: 'Aucun fichier associé' };
    const fullPath = path.join(config.dataDir, fileName);
    const result = await shell.openPath(fullPath);
    return result === '' ? { success: true } : { success: false, error: result };
  });
}

app.whenReady().then(async () => {
  const excelService = new ExcelIndiceService(config);
  const emailService = new EmailActionsService(config);
  const pagerService = new PagerLocatorService(config);
  dataStore = new DataStore(excelService, emailService, pagerService);

  await dataStore.refresh();
  registerIpcHandlers();
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
