class ElectronApiClient {
  async getSnapshot() {
    return window.api.getSnapshot();
  }
  async refresh() {
    return window.api.refresh();
  }
  async openPager(fileName) {
    return window.api.openPager(fileName);
  }
}

export default new ElectronApiClient();
