import IndiceCard from '../components/IndiceCard';

export default function IndicesPage({ sheet }) {
  if (!sheet) return null;
  return (
    <div style={{ padding: '1.5rem' }}>
      <h2 style={{ color: '#A6192E' }}>{sheet.title}</h2>
      {sheet.indices.map((indice) => (
        <IndiceCard key={indice.no} indice={indice} />
      ))}
    </div>
  );
}
