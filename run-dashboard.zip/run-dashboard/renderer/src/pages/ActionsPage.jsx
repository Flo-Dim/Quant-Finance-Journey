import ActionsTable from '../components/ActionsTable';

export default function ActionsPage({ actions }) {
  return (
    <div style={{ padding: '1.5rem' }}>
      <h2 style={{ color: '#A6192E' }}>Tableau de Bord Actions</h2>
      <ActionsTable actions={actions} />
    </div>
  );
}
