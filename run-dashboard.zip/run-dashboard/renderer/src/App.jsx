import { useEffect, useState } from 'react';
import SplashScreen from './components/SplashScreen';
import TopNav from './components/TopNav';
import IndicesPage from './pages/IndicesPage';
import ActionsPage from './pages/ActionsPage';
import ElectronApiClient from './api/ElectronApiClient';
import './theme.css';

export default function App() {
  const [splashDone, setSplashDone] = useState(false);
  const [sheets, setSheets] = useState([]);
  const [actions, setActions] = useState([]);
  const [activeKey, setActiveKey] = useState(null);
  const [lastRefresh, setLastRefresh] = useState(null);
  const [refreshing, setRefreshing] = useState(false);

  const applySnapshot = (snapshot) => {
    setSheets(snapshot.sheets);
    setActions(snapshot.actions);
    setLastRefresh(snapshot.lastRefresh);
    setActiveKey((prev) => prev ?? (snapshot.sheets[0] ? snapshot.sheets[0].sheetName : null));
  };

  useEffect(() => {
    ElectronApiClient.getSnapshot().then(applySnapshot);
  }, []);

  const handleRefresh = async () => {
    setRefreshing(true);
    const snapshot = await ElectronApiClient.refresh();
    applySnapshot(snapshot);
    setRefreshing(false);
  };

  if (!splashDone) {
    return <SplashScreen onFinish={() => setSplashDone(true)} />;
  }

  const activeSheet = sheets.find((s) => s.sheetName === activeKey);

  return (
    <div>
      <TopNav
        sheets={sheets}
        activeKey={activeKey}
        onSelect={setActiveKey}
        onRefresh={handleRefresh}
        refreshing={refreshing}
        lastRefresh={lastRefresh}
      />
      {activeKey === '__actions__' ? (
        <ActionsPage actions={actions} />
      ) : (
        <IndicesPage sheet={activeSheet} />
      )}
    </div>
  );
}
