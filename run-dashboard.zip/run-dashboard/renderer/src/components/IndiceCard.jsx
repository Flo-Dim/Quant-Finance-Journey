import { useState } from 'react';
import ElectronApiClient from '../api/ElectronApiClient';

export default function IndiceCard({ indice }) {
  const [error, setError] = useState(null);

  const handleOpenPager = async () => {
    const result = await ElectronApiClient.openPager(indice.pagerFileName);
    if (!result.success) setError(result.error || "Impossible d'ouvrir le pager");
  };

  return (
    <div style={styles.card}>
      <div style={styles.header}>
        <h3 style={styles.sj}>{indice.sj}</h3>
        {indice.pagerAvailable ? (
          <button onClick={handleOpenPager} style={styles.pagerBtn}>
            📄 Ouvrir le Pager
          </button>
        ) : (
          <span style={styles.pagerMissing}>Pager introuvable</span>
        )}
      </div>

      {error && <div style={{ color: '#A6192E', fontSize: '0.8rem' }}>⚠️ {error}</div>}

      <div style={styles.grid}>
        <Field label="Spot" value={indice.spot} />
        <Field label="Strike" value={indice.strike} />
        <Field label="Coupon" value={indice.cp} />
        <Field label="Rappel Anticipé Automat" value={indice.rappelAnticipeAutomat} pre />
        <Field label="Airbag" value={indice.airbag} />
        <Field label="Capital" value={indice.capital} />
        <Field label="Cadre / UF CGP" value={indice.cadreUfCgp} pre />
        <Field label="Date" value={indice.date ? new Date(indice.date).toLocaleDateString('fr-FR') : ''} />
      </div>

      <div style={styles.description}>
        <strong>Description :</strong>
        <p style={{ whiteSpace: 'pre-wrap' }}>{indice.description}</p>
      </div>
    </div>
  );
}

function Field({ label, value, pre }) {
  return (
    <div style={styles.field}>
      <span style={styles.label}>{label}</span>
      <span style={{ ...styles.value, whiteSpace: pre ? 'pre-wrap' : 'normal' }}>{value ?? '—'}</span>
    </div>
  );
}

const styles = {
  card: { background: '#fff', borderRadius: 10, padding: '1.25rem', boxShadow: '0 1px 4px rgba(0,0,0,0.08)', marginBottom: '1rem' },
  header: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.75rem' },
  sj: { margin: 0, color: '#A6192E', whiteSpace: 'pre-wrap' },
  pagerBtn: { background: '#A6192E', color: '#fff', padding: '0.4rem 0.8rem', borderRadius: 6, border: 'none', cursor: 'pointer', fontSize: '0.8rem', fontWeight: 600 },
  pagerMissing: { fontSize: '0.75rem', color: '#999', fontStyle: 'italic' },
  grid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))', gap: '0.75rem', marginBottom: '0.75rem' },
  field: { display: 'flex', flexDirection: 'column' },
  label: { fontSize: '0.7rem', color: '#888', textTransform: 'uppercase' },
  value: { fontSize: '0.9rem' },
  description: { fontSize: '0.85rem', color: '#444', borderTop: '1px solid #eee', paddingTop: '0.75rem' },
};
