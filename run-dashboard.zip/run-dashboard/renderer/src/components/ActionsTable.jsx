export default function ActionsTable({ actions }) {
  if (!actions || actions.length === 0) {
    return <p style={{ padding: '1.5rem' }}>Aucune donnée disponible.</p>;
  }

  const columns = [
    ['secteur', 'Secteur'], ['name', 'Nom'], ['autocall5Y', 'Autocall 5Y'],
    ['reco', 'Reco'], ['potentiel', 'Potentiel'], ['perf1Y', 'Perf 1Y'],
    ['peAction', 'PE Action'], ['peSecteur', 'PE Secteur'],
    ['pbAction', 'PB Action'], ['pbSecteur', 'PB Secteur'],
    ['baisseMax', 'Baisse Max'], ['hausseMax', 'Hausse Max'],
    ['objectifCours', 'Objectif Cours'], ['dernierCours', 'Dernier Cours'],
    ['minHist', 'Min Hist'], ['maxHist', 'Max Hist'],
  ];

  return (
    <div style={{ overflowX: 'auto', background: '#fff', borderRadius: 10, padding: '1rem' }}>
      <table style={styles.table}>
        <thead>
          <tr>
            {columns.map(([key, label]) => (
              <th key={key} style={styles.th}>{label}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {actions.map((row, i) => (
            <tr key={i} style={i % 2 === 0 ? styles.rowEven : undefined}>
              {columns.map(([key]) => (
                <td key={key} style={styles.td}>{row[key] ?? ''}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

const styles = {
  table: { width: '100%', borderCollapse: 'collapse', fontSize: '0.8rem' },
  th: {
    position: 'sticky', top: 0, background: '#A6192E', color: '#fff',
    padding: '0.5rem', textAlign: 'left', whiteSpace: 'nowrap',
  },
  td: { padding: '0.4rem 0.5rem', borderBottom: '1px solid #eee', whiteSpace: 'nowrap' },
  rowEven: { background: '#faf9f9' },
};
