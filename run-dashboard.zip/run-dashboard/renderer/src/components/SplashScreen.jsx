import { useEffect, useState } from 'react';

export default function SplashScreen({ onFinish }) {
  const [visible, setVisible] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setVisible(false);
      onFinish();
    }, 1500);
    return () => clearTimeout(timer);
  }, [onFinish]);

  if (!visible) return null;

  return (
    <div style={styles.overlay}>
      <div style={styles.card}>
        <h1 style={styles.title}>ODDO BHF</h1>
        <p style={styles.subtitle}>Tableau de bord — Produits Structurés</p>
        <div style={styles.spinner} />
      </div>
    </div>
  );
}

const styles = {
  overlay: {
    position: 'fixed', inset: 0,
    background: 'linear-gradient(135deg, #A6192E, #7d1122)',
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    zIndex: 1000,
  },
  card: { textAlign: 'center', color: '#fff' },
  title: { fontSize: '3rem', margin: 0, letterSpacing: '4px', fontWeight: 700 },
  subtitle: { fontSize: '1rem', opacity: 0.9, marginTop: '0.5rem' },
  spinner: {
    marginTop: '2rem', width: 40, height: 40, borderRadius: '50%',
    border: '4px solid rgba(255,255,255,0.3)', borderTopColor: '#fff',
    animation: 'spin 1s linear infinite', marginLeft: 'auto', marginRight: 'auto',
  },
};
