export default function TopNav({ sheets, activeKey, onSelect, onRefresh, refreshing, lastRefresh }) {
  return (
    <nav style={styles.nav}>
      <div style={styles.tabs}>
        {sheets.map((sheet) => (
          <button
            key={sheet.sheetName}
            onClick={() => onSelect(sheet.sheetName)}
            style={{
              ...styles.tab,
              ...(activeKey === sheet.sheetName ? styles.tabActive : {}),
            }}
          >
            {sheet.title}
          </button>
        ))}
        <button
          onClick={() => onSelect('__actions__')}
          style={{ ...styles.tab, ...(activeKey === '__actions__' ? styles.tabActive : {}) }}
        >
          Tableau de Bord Actions
        </button>
      </div>

      <div style={styles.right}>
        {lastRefresh && (
          <span style={styles.lastRefresh}>
            MAJ : {new Date(lastRefresh).toLocaleTimeString('fr-FR')}
          </span>
        )}
        <button onClick={onRefresh} disabled={refreshing} style={styles.refreshBtn}>
          {refreshing ? 'Actualisation…' : '⟳ Refresh'}
        </button>
      </div>
    </nav>
  );
}

const styles = {
  nav: {
    display: 'flex', justifyContent: 'space-between', alignItems: 'center',
    background: '#fff', padding: '0.75rem 1.5rem', borderBottom: '3px solid #A6192E',
    flexWrap: 'wrap', gap: '0.5rem',
  },
  tabs: { display: 'flex', flexWrap: 'wrap', gap: '0.4rem' },
  tab: {
    border: '1px solid #ddd', background: '#f4f4f4', padding: '0.5rem 0.9rem',
    borderRadius: 6, cursor: 'pointer', fontSize: '0.85rem', fontWeight: 500,
  },
  tabActive: { background: '#A6192E', color: '#fff', borderColor: '#A6192E' },
  right: { display: 'flex', alignItems: 'center', gap: '0.75rem' },
  lastRefresh: { fontSize: '0.75rem', color: '#888' },
  refreshBtn: {
    background: '#1a1a1a', color: '#fff', border: 'none', padding: '0.5rem 1rem',
    borderRadius: 6, cursor: 'pointer', fontWeight: 600,
  },
};
