# RUN Dashboard — ODDO BHF

Application de bureau (Electron + React) pour naviguer dans les indices du
fichier RUN_INDICE.xlsx et consulter le tableau de bord actions.

## 1. Installation (une seule fois)

Depuis la racine du projet :

```bash
npm install
cd renderer
npm install
cd ..
```

## 2. Test en développement (deux terminaux)

Terminal 1 :
```bash
cd renderer
npm run dev
```

Terminal 2 (depuis la racine) :
```bash
npm run dev:electron
```

La fenêtre de l'application doit s'ouvrir automatiquement.

Le dossier `data/` à la racine du projet contient déjà tes vrais fichiers
(`RUN_INDICE.xlsx` et `TABLEAU_DE_BORD_ACTIONS.eml`) pour que le test
fonctionne immédiatement. Les pagers PDF ne sont pas inclus : chaque
indice affichera donc "Pager introuvable" tant que tu n'auras pas ajouté
les vrais PDF dans `data/` (le nom du PDF doit juste contenir le nom du
sous-jacent, ex: `MXTPIC50_pager.pdf`).

## 3. Construire le .exe à donner à tes collègues

```bash
npm run dist
```

Le fichier `dist/RunDashboard.exe` (portable) est généré.

Pour le déploiement final sur le lecteur réseau, dépose :

```
\\VotreServeur\Partage\RunDashboard\
├── RunDashboard.exe
└── data\
    ├── RUN_INDICE.xlsx
    ├── TABLEAU_DE_BORD_ACTIONS.eml
    └── (tous les pagers PDF)
```

Chaque collègue n'a besoin que d'un raccourci vers `RunDashboard.exe`.
Aucune installation, aucune configuration.

## Structure du projet

- `electron/` — processus principal Electron (lecture des fichiers, IPC)
  - `config/AppConfig.js` — résolution automatique du dossier `data/`
  - `models/` — Indice, SheetData, ActionRow
  - `services/` — ExcelIndiceService, EmailActionsService,
    PagerLocatorService, DataStore
- `renderer/` — application React (Vite) affichée dans la fenêtre Electron
- `data/` — fichiers sources (Excel, email, pagers PDF)
